﻿using System;

using UIKit;

namespace REVTest
{
	public partial class ViewController : UIViewController
	{
		protected ViewController(IntPtr handle) : base(handle)
		{
			// Note: this .ctor should not contain any initialization logic.
		}

		DreamTeam.Xamarin.RichEditorView.RichEditorView _editorView;

		public override void ViewDidLoad()
		{
			base.ViewDidLoad();
			// Perform any additional setup after loading the view, typically from a nib.

			_editorView = new DreamTeam.Xamarin.RichEditorView.RichEditorView();
			View.Add(_editorView);
		}

		public override void DidReceiveMemoryWarning()
		{
			base.DidReceiveMemoryWarning();
			// Release any cached data, images, etc that aren't in use.
		}
	}
}
